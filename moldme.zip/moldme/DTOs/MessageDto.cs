namespace moldme.DTOs;

public class MessageDto
{
    public String MessageId { get; set; }
    public String ChatId { get; set; }
    public String EmployeeId { get; set; }
    public string Text { get; set; }
}