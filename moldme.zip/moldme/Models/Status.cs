﻿namespace moldme.Models;

public enum Status
{
    TODO,
    INPROGRESS,
    DONE,
    CLOSED,
    CANCELED,
    PENDING,
    ACCEPTED,
    DENIED,
}