﻿namespace moldme.Models;

public enum SubscriptionPlan
{
    Basic,
    Pro,
    Premium,
}